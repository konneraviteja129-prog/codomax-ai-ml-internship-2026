# Program 4: Reverse a string

text = input("Enter a string: ")
print("Reversed:", text[::-1])
