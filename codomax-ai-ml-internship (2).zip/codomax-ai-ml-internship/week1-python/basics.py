# Python basics: variables, loops, lists, functions

# Variables
name = "Raviteja"
age = 21
height = 5.9
is_student = True
print(name, age, height, is_student)
print(type(age))

# Loops
print("For loop:")
for i in range(1, 6):
    print(i)

print("While loop:")
count = 1
while count <= 3:
    print(count)
    count += 1

# Lists
skills = ["Python", "ML", "SQL"]
skills.append("Deep Learning")
skills.remove("SQL")
print("Skills:", skills)
print("First skill:", skills[0])
print("Total skills:", len(skills))
for skill in skills:
    print("-", skill)


# Functions
def greet(person):
    return "Hello, " + person


print(greet(name))
