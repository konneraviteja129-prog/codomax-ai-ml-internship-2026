# Program 3: Find the largest number in a list

nums = [4, 19, 7, 33, 2]

largest = nums[0]
for n in nums:
    if n > largest:
        largest = n

print("List:", nums)
print("Largest:", largest)
