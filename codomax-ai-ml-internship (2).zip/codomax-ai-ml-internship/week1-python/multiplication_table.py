# Program 2: Print the multiplication table of a number

n = int(input("Table of: "))

for i in range(1, 11):
    print(f"{n} x {i} = {n * i}")
