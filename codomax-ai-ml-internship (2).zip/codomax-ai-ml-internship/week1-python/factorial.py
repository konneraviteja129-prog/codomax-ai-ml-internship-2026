# Program 5: Factorial of a number using a function


def factorial(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result


num = int(input("Enter a number: "))
print(f"Factorial of {num} is {factorial(num)}")
