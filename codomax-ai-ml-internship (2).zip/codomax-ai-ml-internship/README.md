# Codomax AI & ML Internship

Learning notes and Python programs from my 1-month virtual internship
at Codomax Digital Solutions (30 Oct 2026 to 27 Nov 2026).

## Contents
- `week1-python/`: beginner Python programs

## Topics covered
- AI vs ML vs Deep Learning
- Real-world AI applications
- Python basics: variables, loops, lists, functions

## How to run
```bash
python week1-python/even_or_odd.py
```
